#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "bsp.h"
#include "key.h"

uint16_t FFT_IN[FFT_PT]= {0};
uint32_t FFT_IN2[FFT_PT];
uint32_t FFT_OUT[FFT_PT];
uint8_t LED_MODE=0;

int main(void)
{
    delay_init();
    bsp_GOIP_Init();
    bsp_TIMs_Init();
		bsp_TIM2_Int_Init();
    bsp_ADC_Init();
    volatile uint16_t adcValue;
    uint8_t KeyPressTime=0;
    while(1)
    {
        if(1==KEY_Scan(1))
        {
            KeyPressTime++;
        }
        else
        {
            KeyPressTime=0;
        }

        if(KeyPressTime>3)
            LED_MODE=~LED_MODE;
        delay_ms(20);
    }
}


