#ifndef __BSP_H
#define __BSP_H
#include "sys.h"

#define FFT_PT 64
extern uint8_t  LED_MODE;
extern uint16_t FFT_IN[FFT_PT];
extern uint32_t FFT_IN2[FFT_PT];
extern uint32_t FFT_OUT[FFT_PT];

void bsp_TIM2_Int_Init(void);
void bsp_GOIP_Init(void);
void bsp_TIMs_Init(void);
void bsp_ADC_Init(void);
#endif

