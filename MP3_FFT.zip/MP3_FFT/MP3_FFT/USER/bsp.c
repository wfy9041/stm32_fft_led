#include "bsp.h"
#include "sys.h"
#include "string.h"
#include "stm32_dsp.h"
#include "math.h"



void bsp_GOIP_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);

    //DFPlaydr DAC_L DAC_R��ʼ��������ģ������
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //PWM 												FFT8				FFT7				FFT2				 FFT1
    GPIO_InitStructure.GPIO_Pin =GPIO_Pin_6 | GPIO_Pin_7| GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //PWM 														FFT4				 FFT3
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    //PWM													FFT6				 FFT5
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    //PA5  Player/Pause
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

/*
FFT1  PA9 	TIM1_CH2
FFT2  PA8 	TIM1_CH1
FFT3  PC7 	TIM8_CH2
FFT4  PC6 	TIM8_CH1
FFT5  PB1 	TIM3_CH4
FFT6  PB0 	TIM3_CH3
FFT7  PA7 	TIM3_CH2
FFT8  PA6 	TIM3_CH1
*/
void bsp_TIMs_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1 | RCC_APB2Periph_TIM8,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_TimeBaseStructure.TIM_Period=2000;
    TIM_TimeBaseStructure.TIM_Prescaler=35;
    TIM_TimeBaseStructure.TIM_ClockDivision=0;
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3,&TIM_TimeBaseStructure);
    TIM_TimeBaseInit(TIM1,&TIM_TimeBaseStructure);
    TIM_TimeBaseInit(TIM8,&TIM_TimeBaseStructure);

    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM2;
    TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_Low;

    TIM_OC1Init(TIM3,&TIM_OCInitStructure);
    TIM_OC2Init(TIM3,&TIM_OCInitStructure);
    TIM_OC3Init(TIM3,&TIM_OCInitStructure);
    TIM_OC4Init(TIM3,&TIM_OCInitStructure);

    TIM_OC1Init(TIM1,&TIM_OCInitStructure);
    TIM_OC2Init(TIM1,&TIM_OCInitStructure);
    TIM_OC1Init(TIM8,&TIM_OCInitStructure);
    TIM_OC2Init(TIM8,&TIM_OCInitStructure);

    TIM_SetCompare1(TIM3, 0);
    TIM_SetCompare2(TIM3, 0);
    TIM_SetCompare3(TIM3, 0);
    TIM_SetCompare4(TIM3, 0);
    TIM_SetCompare1(TIM1, 0);
    TIM_SetCompare2(TIM1, 0);
    TIM_SetCompare1(TIM8, 0);
    TIM_SetCompare2(TIM8, 0);

    TIM_CCxNCmd(TIM8, TIM_Channel_1, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM8, TIM_Channel_2, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM8, TIM_Channel_3, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM8, TIM_Channel_4, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM1, TIM_Channel_1, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM1, TIM_Channel_2, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM1, TIM_Channel_3, TIM_CCxN_Disable);
    TIM_CCxNCmd(TIM1, TIM_Channel_4, TIM_CCxN_Disable);

    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_CtrlPWMOutputs(TIM8, ENABLE);

    TIM_Cmd(TIM3,ENABLE);
    TIM_Cmd(TIM8,ENABLE);
    TIM_Cmd(TIM1,ENABLE);
}

//TIM2 ���� ADC
void bsp_TIM2_Int_Init(void)
{
	TIM_TimeBaseInitTypeDef   TIM_TimeBaseStructure;
	TIM_OCInitTypeDef         TIM_OCInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
	/* Time Base configuration */
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure); 
	TIM_TimeBaseStructure.TIM_Period = 25;          
	TIM_TimeBaseStructure.TIM_Prescaler = 719;       
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;    
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
	/* TIM1 channel1 configuration in PWM mode */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;                
	TIM_OCInitStructure.TIM_Pulse = 14; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;         
	TIM_OC2Init(TIM2, &TIM_OCInitStructure);
	
	TIM_Cmd(TIM2, ENABLE);
}

void bsp_ADC_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    ADC_DeInit(ADC1);

    ADC_InitTypeDef ADC_InitStructure;
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);

    /* ADC1 regular channel1 configuration */
    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_55Cycles5);

    /* Enable ADC1 */
    ADC_Cmd(ADC1, ENABLE);

    /* Enable ADC1 reset calibration register */
    ADC_ResetCalibration(ADC1);
    /* Check the end of ADC1 reset calibration register */
    while(ADC_GetResetCalibrationStatus(ADC1));

    /* Start ADC1 calibration */
    ADC_StartCalibration(ADC1);
    /* Check the end of ADC1 calibration */
    while(ADC_GetCalibrationStatus(ADC1));

    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    ADC_DMACmd(ADC1,ENABLE);


    DMA_InitTypeDef DMA_InitStructure; // ע��ADCΪ12λģ��ת������ֻ��ADCConvertedValue�ĵ�12λ��Ч
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);//ʹ��DMAʱ��
    DMA_DeInit(DMA1_Channel1);//����DMA1�ĵ�һͨ��
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;//DMA��Ӧ���������ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&FFT_IN; //�ڴ�洢����ַ
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC; //DMA��ת��ģʽΪSRCģʽ����������Ƶ��ڴ�
    DMA_InitStructure.DMA_BufferSize = FFT_PT;//DMA�����С��1��
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable; //����һ�����ݺ��豸��ַ��ֹ����
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable; //�رս���һ�����ݺ�Ŀ���ڴ��ַ����
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;//�����������ݿ���Ϊ16λ
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord; //DMA�������ݳߴ磬HalfWord����Ϊ16λ
    DMA_InitStructure.DMA_Mode =DMA_Mode_Circular;//ѭ��ת��ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;//DMA���ȼ���
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//M2Mģʽ����
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    DMA_ITConfig(DMA1_Channel1,DMA_IT_TC, ENABLE);//ʹ�ܴ�������ж�


    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel=DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
    NVIC_Init(&NVIC_InitStructure);

    DMA_Cmd(DMA1_Channel1,ENABLE);
}


/*
FFT1  PA9 	TIM1_CH2
FFT2  PA8 	TIM1_CH1
FFT3  PC7 	TIM8_CH2
FFT4  PC6 	TIM8_CH1
FFT5  PB1 	TIM3_CH4
FFT6  PB0 	TIM3_CH3
FFT7  PA7 	TIM3_CH2
FFT8  PA6 	TIM3_CH1
*/

void powerMag(long nfill)
{   
		signed short lX,lY;
    float X,Y,Mag;
    unsigned short i;
    for(i=0; i<nfill/2; i++)
    {
        lX  = (FFT_OUT[i] << 16) >> 16;
        lY  = (FFT_OUT[i] >> 16);
        X = nfill * ((float)lX) / 32768;
        Y = nfill * ((float)lY) / 32768;
        Mag = sqrt(X * X + Y * Y) / nfill;
        if(i == 0)
            FFT_OUT[i] = (unsigned long)(Mag * 32768);
        else
            FFT_OUT[i] = (unsigned long)(Mag * 65536);
    }
		memset(&FFT_OUT[nfill/2],0,sizeof(uint32_t)*nfill/2);
}

void DMA1_Channel1_IRQHandler(void)
{
    if(SET==DMA_GetFlagStatus(DMA1_FLAG_TC1))
    {
        DMA_Cmd(DMA1_Channel1,DISABLE);
       
        if(LED_MODE==0)
        {
					for(uint16_t i=0;i<FFT_PT;i++)
					{
						FFT_IN2[i]=FFT_IN[i]<<16;
					}
						cr4_fft_64_stm32(FFT_OUT,FFT_IN2,FFT_PT);
						powerMag(FFT_PT);
					  for(uint8_t i=1;i<=8;i++)
					    if(FFT_OUT[i]<=30)
								FFT_OUT[i]=0;
							else
								FFT_OUT[i]-=30;
            TIM_SetCompare2(TIM1, FFT_OUT[1]*1.5); 	//625		Hz
            TIM_SetCompare1(TIM1, FFT_OUT[2]*1.5); 	//1250	Hz
            TIM_SetCompare2(TIM8, FFT_OUT[3]*1.5);	//1875 Hz
            TIM_SetCompare1(TIM8, FFT_OUT[4]*1.5);	//2500  Hz
            TIM_SetCompare4(TIM3, FFT_OUT[5]*1.5);	//3125  Hz
            TIM_SetCompare3(TIM3, FFT_OUT[6]*1.5);	//3750  Hz
            TIM_SetCompare2(TIM3, FFT_OUT[7]*1.5);	//4375  Hz
            TIM_SetCompare1(TIM3, FFT_OUT[8]*1.5);	//5000  Hz
        }
        else
        {
            TIM_SetCompare2(TIM1, 2000);
            TIM_SetCompare1(TIM1, 2000);
            TIM_SetCompare2(TIM8, 2000);
            TIM_SetCompare1(TIM8, 2000);
            TIM_SetCompare4(TIM3, 2000);
            TIM_SetCompare3(TIM3, 2000);
            TIM_SetCompare2(TIM3, 2000);
            TIM_SetCompare1(TIM3, 2000);
        }
        DMA_ClearITPendingBit(DMA1_FLAG_TC1);
        DMA_Cmd(DMA1_Channel1,ENABLE);
    }
}
